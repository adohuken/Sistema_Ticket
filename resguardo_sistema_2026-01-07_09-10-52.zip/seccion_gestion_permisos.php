<?php
/**
 * seccion_gestion_permisos.php - Gestión de permisos por rol
 * Permite al SuperAdmin asignar/desasignar módulos a cada rol
 */

// Obtener todos los roles
$roles = $pdo->query("SELECT * FROM roles ORDER BY id")->fetchAll();

// Obtener todos los módulos
$modulos = $pdo->query("SELECT * FROM modulos ORDER BY etiqueta")->fetchAll();

// Obtener permisos actuales por rol
$permisos_por_rol = [];
foreach ($roles as $rol) {
    $stmt = $pdo->prepare("SELECT modulo_id FROM permisos_roles WHERE rol_id = ?");
    $stmt->execute([$rol['id']]);
    $permisos_por_rol[$rol['id']] = $stmt->fetchAll(PDO::FETCH_COLUMN);
}
?>

<div class="p-6 space-y-6">
    <!-- Header -->
    <div class="flex items-center justify-between">
        <div>
            <h2 class="text-3xl font-bold text-slate-800 flex items-center gap-3">
                <i class="ri-shield-keyhole-line text-blue-600"></i>
                Gestión de Permisos
            </h2>
            <p class="text-slate-500 mt-1">Asigna o desasigna módulos para cada rol del sistema</p>
        </div>
    </div>

    <?php if (isset($_GET['success']) && $_GET['success'] == '1'): ?>
        <div class="bg-green-50 border-l-4 border-green-500 p-4 rounded-lg">
            <div class="flex items-center gap-2">
                <i class="ri-checkbox-circle-line text-green-600 text-xl"></i>
                <p class="text-green-800 font-medium">Permisos actualizados exitosamente.</p>
            </div>
        </div>
    <?php endif; ?>

    <?php if (isset($mensaje_exito)): ?>
        <div class="bg-green-50 border-l-4 border-green-500 p-4 rounded-lg">
            <div class="flex items-center gap-2">
                <i class="ri-checkbox-circle-line text-green-600 text-xl"></i>
                <p class="text-green-800 font-medium"><?php echo $mensaje_exito; ?></p>
            </div>
        </div>
    <?php endif; ?>

    <?php if (isset($mensaje_error)): ?>
        <div class="bg-red-50 border-l-4 border-red-500 p-4 rounded-lg">
            <div class="flex items-center gap-2">
                <i class="ri-error-warning-line text-red-600 text-xl"></i>
                <p class="text-red-800 font-medium"><?php echo $mensaje_error; ?></p>
            </div>
        </div>
    <?php endif; ?>

    <!-- Tabs de Roles -->
    <div class="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
        <!-- Tab Headers -->
        <div class="flex border-b border-slate-200 bg-slate-50 overflow-x-auto">
            <?php foreach ($roles as $index => $rol): ?>
                <button onclick="cambiarTab('tab-<?php echo $rol['id']; ?>')" id="btn-tab-<?php echo $rol['id']; ?>"
                    class="tab-btn px-6 py-4 font-semibold text-slate-600 hover:text-blue-600 hover:bg-white transition-all border-b-2 border-transparent whitespace-nowrap <?php echo $index === 0 ? 'active' : ''; ?>">
                    <i class="ri-user-settings-line mr-2"></i>
                    <?php echo htmlspecialchars($rol['nombre']); ?>
                </button>
            <?php endforeach; ?>
        </div>

        <!-- Tab Content -->
        <?php foreach ($roles as $index => $rol): ?>
            <div id="tab-<?php echo $rol['id']; ?>" class="tab-content p-6 <?php echo $index === 0 ? '' : 'hidden'; ?>">
                <form method="POST" action="">
                    <input type="hidden" name="rol_id" value="<?php echo $rol['id']; ?>">
                    <input type="hidden" name="actualizar_permisos" value="1">
                    <input type="hidden" name="csrf_token" value="<?php echo generar_csrf_token(); ?>">

                    <div class="mb-6">
                        <h3 class="text-xl font-bold text-slate-800 mb-2"><?php echo htmlspecialchars($rol['nombre']); ?>
                        </h3>
                        <p class="text-slate-600"><?php echo htmlspecialchars($rol['descripcion']); ?></p>
                    </div>

                    <?php
                    // Definición de Grupos y sus Módulos
                    $grupos_config = [
                        'Gestión de Tickets' => ['crear_ticket', 'mis_tickets', 'asignar_tickets', 'mis_tareas', 'seguimiento_tickets'],
                        'Administración' => ['gestion_usuarios', 'gestion_permisos', 'gestion_sucursales', 'categorias', 'dashboard'],
                        'RRHH & Personal' => ['gestion_personal', 'personal_importar', 'rrhh_altas', 'rrhh_historial', 'cargos'],
                        'Inventario & Activos' => ['rrhh_inventario', 'rrhh_registro_equipo', 'rrhh_asignacion_equipos'],
                        'Gestión IT' => ['registros_365', 'mantenimiento_equipos', 'visualizacion_it'],
                        'Reportes & Estadísticas' => ['reportes', 'estadisticas_globales', 'historial_tecnico'],
                        'Sistema & Configuración' => ['configuracion', 'backup_bd', 'restaurar_bd', 'reiniciar_bd']
                    ];

                    // Icon setup
                    $icon_map = [
                        'dashboard' => 'ri-dashboard-3-line',
                        'crear_ticket' => 'ri-add-circle-line',
                        'mis_tickets' => 'ri-ticket-line',
                        'gestion_usuarios' => 'ri-team-line',
                        'asignar_tickets' => 'ri-user-received-line',
                        'mis_tareas' => 'ri-task-line',
                        'reportes' => 'ri-pie-chart-2-line',
                        'rrhh_altas' => 'ri-file-user-line', // Icono actualizado
                        'rrhh_bajas' => 'ri-user-unfollow-line',
                        'rrhh_historial' => 'ri-file-list-3-line',
                        'rrhh_inventario' => 'ri-archive-line',
                        'rrhh_registro_equipo' => 'ri-add-box-line',
                        'rrhh_asignacion_equipos' => 'ri-user-settings-line',
                        'backup_bd' => 'ri-database-2-line',
                        'restaurar_bd' => 'ri-refresh-line',
                        'reiniciar_bd' => 'ri-restart-line',
                        'gestion_permisos' => 'ri-shield-keyhole-line',
                        'seguimiento_tickets' => 'ri-line-chart-line',
                        'configuracion' => 'ri-settings-3-line',
                        'categorias' => 'ri-folder-settings-line',
                        'gestion_personal' => 'ri-contacts-book-line',
                        'gestion_sucursales' => 'ri-building-line',
                        'personal_importar' => 'ri-file-upload-line',
                        'estadisticas_globales' => 'ri-bar-chart-grouped-line',
                        'historial_tecnico' => 'ri-history-line',
                        'mantenimiento_equipos' => 'ri-tools-line',
                        'registros_365' => 'ri-microsoft-line',
                        'cargos' => 'ri-briefcase-4-line',
                        'visualizacion_it' => 'ri-information-line'
                    ];

                    // Overrides para etiquetas (Unificación Visual)
                    $label_overrides = [
                        'rrhh_altas' => 'Formulario Alta/Baja (Unificado)'
                    ];

                    // Organizar módulos en grupos
                    $modulos_por_grupo = [];
                    $modulos_sin_grupo = [];
                    $modulos_asignados_tracker = [];

                    foreach ($modulos as $m) {
                        // Omitir módulos obsoletos o unificados
                        if ($m['nombre'] === 'rrhh_bajas')
                            continue;

                        // Aplicar override de etiqueta si existe
                        if (isset($label_overrides[$m['nombre']])) {
                            $m['etiqueta'] = $label_overrides[$m['nombre']];
                        }

                        $asignado = false;
                        foreach ($grupos_config as $nombre_grupo => $mods) {
                            if (in_array($m['nombre'], $mods)) {
                                $modulos_por_grupo[$nombre_grupo][] = $m;
                                $asignado = true;
                                break;
                            }
                        }
                        if (!$asignado) {
                            $modulos_sin_grupo[] = $m;
                        }
                    }

                    // Renderizar Grupos
                    foreach ($grupos_config as $nombre_grupo => $mods_grupo) {
                        if (empty($modulos_por_grupo[$nombre_grupo]))
                            continue;

                        echo '<div class="mb-8">';
                        echo '<h4 class="text-lg font-bold text-slate-700 mb-4 border-b border-slate-200 pb-2 flex items-center gap-2">';

                        // Icono del grupo
                        $group_icon = 'ri-apps-line';
                        if (strpos($nombre_grupo, 'Ticket') !== false)
                            $group_icon = 'ri-ticket-2-line';
                        if (strpos($nombre_grupo, 'Admin') !== false)
                            $group_icon = 'ri-admin-line';
                        if (strpos($nombre_grupo, 'RRHH') !== false)
                            $group_icon = 'ri-group-line';
                        if (strpos($nombre_grupo, 'Inventario') !== false)
                            $group_icon = 'ri-archive-line';
                        if (strpos($nombre_grupo, 'Reportes') !== false)
                            $group_icon = 'ri-bar-chart-line';
                        if (strpos($nombre_grupo, 'Sistema') !== false)
                            $group_icon = 'ri-settings-4-line';

                        echo "<i class='$group_icon text-blue-500'></i> $nombre_grupo";
                        echo '</h4>';

                        echo '<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">';
                        foreach ($modulos_por_grupo[$nombre_grupo] as $modulo) {
                            $checked = in_array($modulo['id'], $permisos_por_rol[$rol['id']]) ? 'checked' : '';
                            $icon = $icon_map[$modulo['nombre']] ?? 'ri-checkbox-circle-line';
                            ?>
                            <label
                                class="flex items-start gap-3 p-4 border border-slate-200 rounded-xl hover:border-blue-400 hover:bg-blue-50/50 transition-all cursor-pointer group bg-white shadow-sm hover:shadow-md">
                                <input type="checkbox" name="modulos[]" value="<?php echo $modulo['id']; ?>" <?php echo $checked; ?>
                                    class="mt-1 w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500 border-slate-300">
                                <div class="flex-1">
                                    <div class="flex items-center gap-2 mb-1">
                                        <div
                                            class="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
                                            <i class="<?php echo $icon; ?> text-lg"></i>
                                        </div>
                                        <span class="font-semibold text-slate-800 group-hover:text-blue-700 transition-colors">
                                            <?php echo htmlspecialchars($modulo['etiqueta']); ?>
                                        </span>
                                    </div>
                                    <p class="text-xs text-slate-500 pl-[42px] leading-relaxed">
                                        <?php echo htmlspecialchars($modulo['descripcion']); ?>
                                    </p>
                                </div>
                            </label>
                            <?php
                        }
                        echo '</div></div>';
                    }

                    // Renderizar Otros (Sin Grupo)
                    if (!empty($modulos_sin_grupo)) {
                        echo '<div class="mb-6">';
                        echo '<h4 class="text-lg font-bold text-slate-700 mb-4 border-b border-slate-200 pb-2 flex items-center gap-2"><i class="ri-more-2-line text-slate-400"></i> Otros Módulos</h4>';
                        echo '<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">';
                        foreach ($modulos_sin_grupo as $modulo) {
                            $checked = in_array($modulo['id'], $permisos_por_rol[$rol['id']]) ? 'checked' : '';
                            $icon = $icon_map[$modulo['nombre']] ?? 'ri-checkbox-circle-line';
                            ?>
                            <label
                                class="flex items-start gap-3 p-4 border border-slate-200 rounded-xl hover:border-blue-400 hover:bg-blue-50/50 transition-all cursor-pointer group bg-white shadow-sm hover:shadow-md">
                                <input type="checkbox" name="modulos[]" value="<?php echo $modulo['id']; ?>" <?php echo $checked; ?>
                                    class="mt-1 w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500 border-slate-300">
                                <div class="flex-1">
                                    <div class="flex items-center gap-2 mb-1">
                                        <div
                                            class="w-8 h-8 rounded-lg bg-slate-50 text-slate-500 flex items-center justify-center group-hover:bg-slate-600 group-hover:text-white transition-colors">
                                            <i class="<?php echo $icon; ?> text-lg"></i>
                                        </div>
                                        <span class="font-semibold text-slate-800 group-hover:text-slate-900 transition-colors">
                                            <?php echo htmlspecialchars($modulo['etiqueta']); ?>
                                        </span>
                                    </div>
                                    <p class="text-xs text-slate-500 pl-[42px] leading-relaxed">
                                        <?php echo htmlspecialchars($modulo['descripcion']); ?>
                                    </p>
                                </div>
                            </label>
                            <?php
                        }
                        echo '</div></div>';
                    }
                    ?>

                    <!-- Botón Guardar -->
                    <div class="flex justify-end gap-3">
                        <button type="submit"
                            class="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-lg transition-all shadow-lg shadow-blue-600/30 hover:shadow-xl">
                            <i class="ri-save-line text-xl"></i>
                            Guardar Permisos
                        </button>
                    </div>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script>
    function cambiarTab(tabId) {
        // Ocultar todos los tabs
        document.querySelectorAll('.tab-content').forEach(tab => {
            tab.classList.add('hidden');
        });

        // Remover clase active de todos los botones
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active', 'text-blue-600', 'border-blue-600', 'bg-white');
            btn.classList.add('text-slate-600', 'border-transparent');
        });

        // Mostrar tab seleccionado
        document.getElementById(tabId).classList.remove('hidden');

        // Activar botón correspondiente
        const btn = document.getElementById('btn-' + tabId);
        btn.classList.add('active', 'text-blue-600', 'border-blue-600', 'bg-white');
        btn.classList.remove('text-slate-600', 'border-transparent');
    }
</script>

<style>
    .tab-btn.active {
        color: #2563eb;
        border-bottom-color: #2563eb;
        background-color: white;
    }
</style>