<?php
/**
 * footer.php - Pie de página y cierre de contenedores
 */
?>
</main> <!-- cierre de main -->
<footer class="py-6 text-center text-slate-400 text-sm font-medium border-t border-slate-200/50 mt-auto">
    <p>&copy; <?php echo date('Y'); ?> Sistema de Gestión de Tickets <span class="mx-2">•</span> v2.0 Premium</p>
</footer>
</div> <!-- cierre del wrapper pt-24 -->
</div> <!-- cierre del contenedor principal ml-72 -->