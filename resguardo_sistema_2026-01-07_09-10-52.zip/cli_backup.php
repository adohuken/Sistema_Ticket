<?php
require_once 'conexion.php';

$filename = 'sistema_ticket_backup_' . date('Y-m-d_H-i-s') . '.sql';

try {
    // Obtener todas las tablas
    $tables = [];
    $result = $pdo->query("SHOW TABLES");
    while ($row = $result->fetch(PDO::FETCH_NUM)) {
        $tables[] = $row[0];
    }

    $output = "-- Backup de Base de Datos - Sistema de Tickets\n";
    $output .= "-- Fecha: " . date('Y-m-d H:i:s') . "\n";
    $output .= "-- Generado por: CLI Backup Tool\n\n";

    $output .= "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n";
    $output .= "START TRANSACTION;\n";
    $output .= "SET time_zone = \"+00:00\";\n\n";

    foreach ($tables as $table) {
        $output .= "-- Estructura de tabla para la tabla `$table`\n";
        $output .= "DROP TABLE IF EXISTS `$table`;\n";
        $create = $pdo->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_ASSOC);
        $output .= $create['Create Table'] . ";\n\n";

        $output .= "-- Volcado de datos para la tabla `$table`\n";
        $rows = $pdo->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);

        if (count($rows) > 0) {
            $output .= "INSERT INTO `$table` VALUES \n";
            $values = [];
            foreach ($rows as $row) {
                $row_values = array_map(function ($v) use ($pdo) {
                    if ($v === null)
                        return 'NULL';
                    return $pdo->quote($v);
                }, $row);
                $values[] = "(" . implode(',', $row_values) . ")";
            }
            $output .= implode(",\n", $values) . ";\n";
        }
        $output .= "\n";
    }

    $output .= "COMMIT;\n";

    file_put_contents($filename, $output);
    echo "Backup creado exitosamente: " . $filename;

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit(1);
}
?>