<?php
/**
 * seccion_mantenimiento_equipos.php - Control de Mantenimiento de Equipos
 */

// Filtros
$filtro_estado = $_GET['estado'] ?? 'En Proceso'; // Por defecto mostrar activos
$filtro_tipo = $_GET['tipo'] ?? '';

// Construir query
$sql = "
    SELECT m.*, 
           i.tipo as equipo_tipo, i.marca, i.modelo, i.serial,
           CONCAT(u.nombres, ' ', u.apellidos) as tecnico_nombre
    FROM mantenimiento_equipos m
    JOIN inventario i ON m.equipo_id = i.id
    LEFT JOIN vista_personal_completo u ON m.registrado_por = u.id
    WHERE 1=1
";

$params = [];

if ($filtro_estado && $filtro_estado !== 'Todos') {
    $sql .= " AND m.estado = ?";
    $params[] = $filtro_estado;
}

if ($filtro_tipo) {
    $sql .= " AND m.tipo_mantenimiento = ?";
    $params[] = $filtro_tipo;
}

$sql .= " ORDER BY m.fecha_inicio DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$mantenimientos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Estadísticas rápidas
$stmt_stats = $pdo->query("
    SELECT 
        SUM(CASE WHEN estado = 'En Proceso' THEN 1 ELSE 0 END) as en_proceso,
        SUM(CASE WHEN estado = 'Programado' THEN 1 ELSE 0 END) as programados,
        SUM(CASE WHEN estado = 'Completado' AND MONTH(fecha_fin) = MONTH(CURRENT_DATE()) THEN 1 ELSE 0 END) as completados_mes
    FROM mantenimiento_equipos
");
$stats = $stmt_stats->fetch(PDO::FETCH_ASSOC);
?>

<div class="p-6 flex-1">
    <div class="max-w-7xl mx-auto space-y-6">
        <!-- Header -->
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 class="text-3xl font-bold text-slate-800 flex items-center gap-3">
                    <span class="bg-amber-600 text-white p-3 rounded-xl shadow-lg shadow-amber-500/30">
                        <i class="ri-tools-fill"></i>
                    </span>
                    Control de Mantenimiento
                </h1>
                <p class="text-slate-500 mt-2">Gestión de reparaciones, mantenimiento preventivo y upgrades</p>
            </div>
            <!-- Botón para registrar mantenimiento general (sin equipo pre-seleccionado) -->
            <button onclick="abrirModalMantenimiento()"
                class="bg-amber-600 hover:bg-amber-700 text-white px-6 py-3 rounded-xl font-semibold shadow-lg shadow-amber-500/30 transition-all flex items-center gap-2">
                <i class="ri-add-line text-xl"></i>
                Registrar Mantenimiento
            </button>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                <div class="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-2xl">
                    <i class="ri-loader-4-line"></i>
                </div>
                <div>
                    <h3 class="text-2xl font-bold text-slate-800"><?= $stats['en_proceso'] ?></h3>
                    <p class="text-sm text-slate-500">En Proceso</p>
                </div>
            </div>
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                <div
                    class="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center text-2xl">
                    <i class="ri-calendar-event-line"></i>
                </div>
                <div>
                    <h3 class="text-2xl font-bold text-slate-800"><?= $stats['programados'] ?></h3>
                    <p class="text-sm text-slate-500">Programados</p>
                </div>
            </div>
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                <div class="w-12 h-12 rounded-xl bg-green-50 text-green-600 flex items-center justify-center text-2xl">
                    <i class="ri-checkbox-circle-line"></i>
                </div>
                <div>
                    <h3 class="text-2xl font-bold text-slate-800"><?= $stats['completados_mes'] ?></h3>
                    <p class="text-sm text-slate-500">Completados este Mes</p>
                </div>
            </div>
        </div>

        <!-- Filtros -->
        <div class="bg-white p-4 rounded-xl shadow-sm border border-slate-100">
            <form action="" method="GET" class="flex flex-wrap gap-4 items-end">
                <input type="hidden" name="view" value="mantenimiento_equipos">

                <div class="w-48">
                    <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Estado</label>
                    <select name="estado"
                        class="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none bg-white">
                        <option value="Todos" <?= $filtro_estado == 'Todos' ? 'selected' : '' ?>>Todos</option>
                        <option value="En Proceso" <?= $filtro_estado == 'En Proceso' ? 'selected' : '' ?>>En Proceso
                        </option>
                        <option value="Programado" <?= $filtro_estado == 'Programado' ? 'selected' : '' ?>>Programado
                        </option>
                        <option value="Completado" <?= $filtro_estado == 'Completado' ? 'selected' : '' ?>>Completado
                        </option>
                        <option value="Cancelado" <?= $filtro_estado == 'Cancelado' ? 'selected' : '' ?>>Cancelado</option>
                    </select>
                </div>

                <div class="w-48">
                    <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Tipo</label>
                    <select name="tipo"
                        class="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none bg-white">
                        <option value="">Todos</option>
                        <option value="Preventivo" <?= $filtro_tipo == 'Preventivo' ? 'selected' : '' ?>>Preventivo
                        </option>
                        <option value="Correctivo" <?= $filtro_tipo == 'Correctivo' ? 'selected' : '' ?>>Correctivo
                        </option>
                        <option value="Upgrade" <?= $filtro_tipo == 'Upgrade' ? 'selected' : '' ?>>Upgrade</option>
                    </select>
                </div>

                <button type="submit"
                    class="px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-900 transition-colors">
                    Filtrar
                </button>
            </form>
        </div>

        <!-- Tabla -->
        <div class="bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-slate-50 border-b border-slate-200">
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">
                                Equipo</th>
                            <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">
                                Tipo / Problema</th>
                            <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">
                                Estado</th>
                            <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">
                                Proveedor</th>
                            <th class="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">
                                Fechas</th>
                            <th class="px-6 py-4 text-right text-xs font-bold text-slate-500 uppercase tracking-wider">
                                Acciones</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php if (empty($mantenimientos)): ?>
                            <tr>
                                <td colspan="6" class="px-6 py-12 text-center text-slate-400">
                                    <i class="ri-inbox-line text-4xl mb-2 block"></i>
                                    No se encontraron registros de mantenimiento
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($mantenimientos as $m): ?>
                                <tr class="hover:bg-slate-50 transition-colors group">
                                    <td class="px-6 py-4">
                                        <div class="font-semibold text-slate-800">
                                            <?= htmlspecialchars($m['equipo_tipo'] . ' ' . $m['marca']) ?>
                                        </div>
                                        <div class="text-xs text-slate-500"><?= htmlspecialchars($m['modelo']) ?></div>
                                        <code
                                            class="text-xs bg-slate-100 px-1 rounded"><?= htmlspecialchars($m['serial']) ?></code>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-sm font-medium text-slate-700">
                                            <?= htmlspecialchars($m['tipo_mantenimiento']) ?>
                                        </div>
                                        <div class="text-xs text-slate-500 truncate max-w-[200px]"
                                            title="<?= htmlspecialchars($m['descripcion_problema']) ?>">
                                            <?= htmlspecialchars($m['descripcion_problema']) ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <?php
                                        $badges = [
                                            'En Proceso' => 'bg-blue-100 text-blue-700',
                                            'Programado' => 'bg-purple-100 text-purple-700',
                                            'Completado' => 'bg-green-100 text-green-700',
                                            'Cancelado' => 'bg-red-100 text-red-700'
                                        ];
                                        $badge = $badges[$m['estado']] ?? 'bg-slate-100 text-slate-600';
                                        ?>
                                        <span
                                            class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?= $badge ?>">
                                            <?= $m['estado'] ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-sm text-slate-700"><?= htmlspecialchars($m['proveedor'] ?: '-') ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-slate-500">
                                        <div>Inicio: <?= date('d/m/Y', strtotime($m['fecha_inicio'])) ?></div>
                                        <?php if ($m['fecha_fin']): ?>
                                            <div class="text-xs">Fin: <?= date('d/m/Y', strtotime($m['fecha_fin'])) ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 text-right">
                                        <button onclick='editarMantenimiento(<?= json_encode($m) ?>)'
                                            class="p-2 bg-white border border-slate-200 rounded-lg text-slate-600 hover:text-amber-600 hover:border-amber-600 transition-all shadow-sm"
                                            title="Editar / Gestionar">
                                            <i class="ri-edit-line"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Mantenimiento -->
<div id="modal-mantenimiento"
    class="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 hidden items-center justify-center">
    <div class="bg-white rounded-2xl shadow-2xl max-w-2xl w-full mx-4 overflow-hidden max-h-[90vh] overflow-y-auto">
        <div class="bg-amber-600 px-6 py-4 flex justify-between items-center">
            <h3 class="text-xl font-bold text-white flex items-center gap-2" id="modal-titulo">
                <i class="ri-tools-fill"></i> Registrar Mantenimiento
            </h3>
            <button onclick="cerrarModalMantenimiento()" class="text-white/80 hover:text-white transition-colors">
                <i class="ri-close-line text-2xl"></i>
            </button>
        </div>

        <form method="POST" action="index.php" class="p-6 space-y-6">
            <input type="hidden" name="accion" id="form-accion" value="registrar_mantenimiento">
            <input type="hidden" name="id" id="mantenimiento-id" value="">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
            <input type="hidden" name="view" value="mantenimiento_equipos">

            <!-- Selección de Equipo -->
            <div id="div-seleccion-equipo" class="bg-slate-50 p-4 rounded-xl border-2 border-slate-200">
                <label class="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-2">
                    <i class="ri-computer-line text-amber-600"></i>
                    Equipo <span class="text-red-500">*</span>
                </label>
                <?php
                $stmt_eq = $pdo->query("SELECT id, tipo, marca, modelo, serial FROM inventario ORDER BY tipo, marca");
                $equipos_list = $stmt_eq->fetchAll(PDO::FETCH_ASSOC);
                ?>
                <select name="equipo_id" id="equipo_id"
                    class="w-full px-4 py-3 border-2 border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none bg-white">
                    <option value="">🔍 Seleccionar Equipo...</option>
                    <?php foreach ($equipos_list as $eq): ?>
                        <option value="<?= $eq['id'] ?>">
                            <?= htmlspecialchars($eq['tipo'] . ' - ' . $eq['marca'] . ' ' . $eq['modelo'] . ' (' . $eq['serial'] . ')') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div id="div-info-equipo" class="hidden bg-blue-50 p-4 rounded-xl border-2 border-blue-200">
                <p class="font-bold text-blue-800 flex items-center gap-2">
                    <i class="ri-information-line"></i>
                    <span id="info-equipo-texto"></span>
                </p>
            </div>

            <!-- Sección: Información Básica -->
            <div class="border-t-2 border-slate-100 pt-4">
                <h4 class="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <i class="ri-file-list-3-line text-amber-600"></i>
                    Información Básica
                </h4>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-1">
                            <i class="ri-tools-line text-xs"></i> Tipo
                        </label>
                        <select name="tipo_mantenimiento" id="tipo_mantenimiento" required
                            class="w-full px-4 py-2.5 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none bg-white">
                            <option value="Preventivo">🛡️ Preventivo</option>
                            <option value="Correctivo">🔧 Correctivo</option>
                            <option value="Upgrade">⬆️ Upgrade</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-1">
                            <i class="ri-flag-line text-xs"></i> Prioridad <span class="text-red-500">*</span>
                        </label>
                        <select name="prioridad" id="prioridad" required
                            class="w-full px-4 py-2.5 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none bg-white">
                            <option value="Baja">🟢 Baja</option>
                            <option value="Media" selected>🟡 Media</option>
                            <option value="Alta">🟠 Alta</option>
                            <option value="Urgente">🔴 Urgente</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-1">
                            <i class="ri-checkbox-circle-line text-xs"></i> Estado
                        </label>
                        <select name="estado" id="estado" required
                            class="w-full px-4 py-2.5 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none bg-white">
                            <option value="Programado">📅 Programado</option>
                            <option value="En Proceso">⚙️ En Proceso</option>
                            <option value="Completado">✅ Completado</option>
                            <option value="Cancelado">❌ Cancelado</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Sección: Planificación -->
            <div class="border-t-2 border-slate-100 pt-4">
                <h4 class="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <i class="ri-calendar-line text-amber-600"></i>
                    Planificación
                </h4>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-1">
                            <i class="ri-calendar-check-line text-xs"></i> Fecha Inicio
                        </label>
                        <input type="date" name="fecha_inicio" id="fecha_inicio"
                            value="<?= date('Y-m-d') ?>"
                            class="w-full px-4 py-2.5 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-1">
                            <i class="ri-calendar-event-line text-xs"></i> Fecha Estimada Fin
                        </label>
                        <input type="date" name="fecha_estimada_fin" id="fecha_estimada_fin"
                            class="w-full px-4 py-2.5 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-1">
                            <i class="ri-time-line text-xs"></i> Horas Estimadas
                        </label>
                        <input type="number" step="0.5" name="horas_estimadas" id="horas_estimadas"
                            value="0" min="0"
                            class="w-full px-4 py-2.5 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none"
                            placeholder="Ej: 2.5">
                    </div>
                </div>
            </div>

            <!-- Sección: Asignación -->
            <div class="border-t-2 border-slate-100 pt-4">
                <h4 class="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <i class="ri-user-settings-line text-amber-600"></i>
                    Asignación y Proveedor
                </h4>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-1">
                            <i class="ri-user-line text-xs"></i> Responsable Asignado
                        </label>
                        <?php
                        $stmt_users = $pdo->query("SELECT id, nombres, apellidos FROM vista_personal_completo WHERE estado = 'Activo' ORDER BY nombres");
                        $usuarios_list = $stmt_users->fetchAll(PDO::FETCH_ASSOC);
                        ?>
                        <select name="responsable_id" id="responsable_id"
                            class="w-full px-4 py-2.5 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none bg-white">
                            <option value="">-- Sin Asignar --</option>
                            <?php foreach ($usuarios_list as $usr): ?>
                                <option value="<?= $usr['id'] ?>">
                                    <?= htmlspecialchars($usr['nombres'] . ' ' . $usr['apellidos']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-1">
                            <i class="ri-service-line text-xs"></i> Proveedor / Técnico Externo
                        </label>
                        <input type="text" name="proveedor" id="proveedor"
                            class="w-full px-4 py-2.5 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none"
                            placeholder="Ej: HP Support, Dell, Interno...">
                    </div>
                </div>
            </div>

            <!-- Sección: Descripciones -->
            <div class="border-t-2 border-slate-100 pt-4">
                <h4 class="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <i class="ri-file-text-line text-amber-600"></i>
                    Descripciones
                </h4>
                
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-1">
                            <i class="ri-error-warning-line text-red-500"></i> 
                            Descripción del Problema / Tarea <span class="text-red-500">*</span>
                        </label>
                        <textarea name="descripcion_problema" id="descripcion_problema" required rows="3"
                            class="w-full px-4 py-3 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none resize-none"
                            placeholder="Describe el problema, falla o tarea a realizar..."></textarea>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-1">
                            <i class="ri-check-double-line text-green-600"></i> 
                            Descripción Solución / Trabajo Realizado
                        </label>
                        <textarea name="descripcion_solucion" id="descripcion_solucion" rows="3"
                            class="w-full px-4 py-3 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-green-500 outline-none resize-none"
                            placeholder="Solo si ya se realizó el trabajo..."></textarea>
                    </div>
                </div>
            </div>

            <!-- Footer con botones -->
            <div class="flex justify-end gap-3 pt-6 border-t-2 border-slate-200">
                <button type="button" onclick="cerrarModalMantenimiento()"
                    class="px-6 py-2.5 border-2 border-slate-300 text-slate-700 rounded-lg hover:bg-slate-100 font-semibold transition-all flex items-center gap-2">
                    <i class="ri-close-line"></i> Cancelar
                </button>
                <button type="submit"
                    class="px-6 py-2.5 bg-amber-600 text-white font-bold rounded-lg hover:bg-amber-700 shadow-lg shadow-amber-500/30 transition-all flex items-center gap-2">
                    <i class="ri-save-line"></i> Guardar Registro
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function abrirModalMantenimiento() {
        document.getElementById('form-accion').value = 'registrar_mantenimiento';
        document.getElementById('mantenimiento-id').value = '';
        document.getElementById('modal-titulo').innerHTML = '<i class="ri-tools-fill"></i> Registrar Mantenimiento';

        // Reset inputs
        document.getElementById('equipo_id').value = '';
        document.getElementById('div-seleccion-equipo').classList.remove('hidden');
        document.getElementById('div-info-equipo').classList.add('hidden');
        document.getElementById('tipo_mantenimiento').value = 'Preventivo';
        document.getElementById('prioridad').value = 'Media';
        document.getElementById('estado').value = 'Programado';
        document.getElementById('fecha_inicio').value = '<?= date('Y-m-d') ?>';
        document.getElementById('fecha_estimada_fin').value = '';
        document.getElementById('horas_estimadas').value = '0';
        document.getElementById('responsable_id').value = '';
        document.getElementById('proveedor').value = '';
        document.getElementById('descripcion_problema').value = '';
        document.getElementById('descripcion_solucion').value = '';

        document.getElementById('modal-mantenimiento').classList.remove('hidden');
        document.getElementById('modal-mantenimiento').classList.add('flex');
    }

    function editarMantenimiento(data) {
        document.getElementById('form-accion').value = 'actualizar_mantenimiento';
        document.getElementById('mantenimiento-id').value = data.id;
        document.getElementById('modal-titulo').innerHTML = '<i class="ri-edit-line"></i> Editar Mantenimiento';

        // Ocultar select de equipo y mostrar info texto
        document.getElementById('div-seleccion-equipo').classList.add('hidden');
        document.getElementById('div-info-equipo').classList.remove('hidden');
        document.getElementById('info-equipo-texto').textContent = `Equipo: ${data.equipo_tipo} ${data.marca} ${data.modelo} (${data.serial})`;

        document.getElementById('tipo_mantenimiento').value = data.tipo_mantenimiento;
        document.getElementById('prioridad').value = data.prioridad || 'Media';
        document.getElementById('estado').value = data.estado;
        document.getElementById('fecha_inicio').value = data.fecha_inicio || '';
        document.getElementById('fecha_estimada_fin').value = data.fecha_estimada_fin || '';
        document.getElementById('horas_estimadas').value = data.horas_estimadas || '0';
        document.getElementById('responsable_id').value = data.responsable_id || '';
        document.getElementById('descripcion_problema').value = data.descripcion_problema;
        document.getElementById('descripcion_solucion').value = data.descripcion_solucion || '';
        document.getElementById('proveedor').value = data.proveedor || '';

        document.getElementById('modal-mantenimiento').classList.remove('hidden');
        document.getElementById('modal-mantenimiento').classList.add('flex');
    }

    function cerrarModalMantenimiento() {
        document.getElementById('modal-mantenimiento').classList.add('hidden');
        document.getElementById('modal-mantenimiento').classList.remove('flex');
    }
</script>